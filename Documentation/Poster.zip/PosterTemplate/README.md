# Poster Template

Compile with `make`. `make clean` will delete auxiliary files. If you want
more/fewer columns, you will have to modify the `\colwidth` variable and
add/delete `\column` environments.
